// Validates email format
export const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

// Validates Indian phone number (10 digits, optionally starting with +91)
export const isValidPhone = (phone: string): boolean => {
  const phoneRegex = /^(\+91)?[6-9]\d{9}$/;
  return phoneRegex.test(phone.replace(/\s+/g, ''));
};

// Returns appropriate error message if validation fails
export const validateInput = (value: string): string | null => {
  const trimmedValue = value.trim();
  
  if (!trimmedValue) {
    return 'Enter your email or mobile phone number';
  }

  // Check if input is a phone number (contains only digits, spaces, and optionally +91)
  if (/^[\d\s+]+$/.test(trimmedValue)) {
    return isValidPhone(trimmedValue) 
      ? null 
      : 'Please enter a valid 10-digit mobile number';
  }

  // Otherwise treat as email
  return isValidEmail(trimmedValue)
    ? null
    : 'Enter a valid email address';
};