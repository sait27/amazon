import React from 'react';
import Logo from './components/Logo';
import LoginForm from './components/LoginForm';
import CreateAccount from './components/CreateAccount';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white flex flex-col items-center pt-4">
      <Logo />
      <LoginForm />
      <CreateAccount />
      <Footer />
    </div>
  );
}

export default App;