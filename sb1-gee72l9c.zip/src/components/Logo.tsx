import React from 'react';

export default function Logo() {
  return (
    <a href="https://www.amazon.in/ref=ap_frn_logo" className="mb-4">
      <div className="flex items-center">
        <img 
          src="https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg" 
          alt="Amazon" 
          className="h-8"
        />
        <span className="text-[#111111] text-xl font-normal">.in</span>
      </div>
    </a>
  );
}