import React, { useState } from 'react';
import { validateInput } from '../utils/validation';

interface EmailFormProps {
  email: string;
  setEmail: (email: string) => void;
  onSubmit: (e: React.FormEvent) => void;
}

export default function EmailForm({ email, setEmail, onSubmit }: EmailFormProps) {
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validationError = validateInput(email);
    
    if (validationError) {
      setError(validationError);
      return;
    }
    
    setError(null);
    onSubmit(e);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="email" className="block text-sm font-bold mb-1">
          Email or mobile phone number
        </label>
        <input
          type="text"
          id="email"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
            setError(null); // Clear error when input changes
          }}
          className={`w-full px-3 py-1 border rounded focus:ring-1 ${
            error 
              ? 'border-red-600 focus:border-red-600 focus:ring-red-600' 
              : 'border-gray-400 focus:border-orange-600 focus:ring-orange-600'
          }`}
          required
        />
        {error && (
          <div className="mt-1 text-xs text-red-600">
            {error}
          </div>
        )}
      </div>

      <button
        type="submit"
        className="w-full bg-[#FFD814] hover:bg-[#F7CA00] border border-[#FCD200] rounded 
                 shadow-[0_2px_5px_0_rgba(213,217,217,.5)] 
                 py-1 px-4 text-sm"
      >
        Continue
      </button>

      <p className="text-xs">
        By continuing, you agree to Amazon's{' '}
        <a href="#" className="text-blue-600 hover:text-orange-700 hover:underline">Conditions of Use</a>{' '}
        and{' '}
        <a href="#" className="text-blue-600 hover:text-orange-700 hover:underline">Privacy Notice</a>.
      </p>

      <div>
        <a href="#" className="text-xs text-blue-600 hover:text-orange-700 hover:underline flex items-center">
          <span className="text-xs">›</span>
          <span className="ml-1">Need help?</span>
        </a>
      </div>
    </form>
  );
}