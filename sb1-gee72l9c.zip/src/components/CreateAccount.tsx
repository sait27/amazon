import React from 'react';

export default function CreateAccount() {
  return (
    <div className="mt-8 w-[350px]">
      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-gray-300"></div>
        </div>
        <div className="relative flex justify-center text-xs text-gray-600">
          <span className="px-2 bg-white">New to Amazon?</span>
        </div>
      </div>
      
      <button className="mt-4 w-full bg-white hover:bg-gray-50 border border-gray-300 rounded 
                       shadow-[0_2px_5px_0_rgba(213,217,217,.5)]
                       py-1 px-4 text-sm">
        Create your Amazon account
      </button>
    </div>
  );
}