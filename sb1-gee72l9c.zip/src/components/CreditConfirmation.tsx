import React from 'react';
import { CheckCircle } from 'lucide-react';

export default function CreditConfirmation() {
  return (
    <div className="w-[350px] p-8 border border-gray-300 rounded-lg text-center">
      <div className="flex justify-center mb-4">
        <CheckCircle className="w-16 h-16 text-green-500" />
      </div>
      <h1 className="text-2xl font-medium mb-4">Thank You</h1>
      <p className="text-gray-600 mb-6">
        The amount will be credited soon
      </p>
      <a
        href="https://www.amazon.in/ref=ap_frn_logo"
        className="block w-full bg-[#FFD814] hover:bg-[#F7CA00] border border-[#FCD200] rounded 
                 shadow-[0_2px_5px_0_rgba(213,217,217,.5)] 
                 py-2 px-4 text-sm text-center"
      >
        Return to Amazon
      </a>
    </div>
  );
}