import React, { useState } from 'react';
import EmailForm from './EmailForm';
import CreditConfirmation from './CreditConfirmation';

export default function LoginForm() {
  const [email, setEmail] = useState('');
  const [showConfirmation, setShowConfirmation] = useState(false);

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setShowConfirmation(true);
    }
  };

  return (
    <div className="w-[350px] p-5 border border-gray-300 rounded-lg">
      {!showConfirmation ? (
        <>
          <h1 className="text-3xl font-normal mb-4">Sign in</h1>
          <EmailForm 
            email={email}
            setEmail={setEmail}
            onSubmit={handleEmailSubmit}
          />
        </>
      ) : (
        <CreditConfirmation />
      )}
    </div>
  );
}