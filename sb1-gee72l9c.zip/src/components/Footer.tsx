import React from 'react';

export default function Footer() {
  return (
    <footer className="mt-8 text-xs text-center space-y-4">
      <div className="flex justify-center space-x-4">
        <a href="#" className="text-blue-600 hover:text-orange-700 hover:underline">Conditions of Use</a>
        <a href="#" className="text-blue-600 hover:text-orange-700 hover:underline">Privacy Notice</a>
        <a href="#" className="text-blue-600 hover:text-orange-700 hover:underline">Help</a>
      </div>
      <div className="text-gray-600">
        © 1996-2024, Amazon.com, Inc. or its affiliates
      </div>
    </footer>
  );
}