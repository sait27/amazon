import React from 'react';

interface PasswordFormProps {
  email: string;
  password: string;
  setPassword: (password: string) => void;
  onSubmit: (e: React.FormEvent) => void;
  onChangeEmail: () => void;
}

export default function PasswordForm({ 
  email, 
  password, 
  setPassword, 
  onSubmit,
  onChangeEmail 
}: PasswordFormProps) {
  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="mb-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">{email}</span>
          <button
            type="button"
            onClick={onChangeEmail}
            className="text-sm text-blue-600 hover:text-orange-700 hover:underline"
          >
            Change
          </button>
        </div>
      </div>

      <div>
        <label htmlFor="password" className="block text-sm font-bold mb-1">
          Password
        </label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full px-3 py-1 border border-gray-400 rounded focus:border-orange-600 focus:ring-1 focus:ring-orange-600"
          required
        />
      </div>

      <button
        type="submit"
        className="w-full bg-[#FFD814] hover:bg-[#F7CA00] border border-[#FCD200] rounded 
                 shadow-[0_2px_5px_0_rgba(213,217,217,.5)] 
                 py-1 px-4 text-sm"
      >
        Sign in
      </button>

      <div>
        <a href="#" className="text-xs text-blue-600 hover:text-orange-700 hover:underline flex items-center">
          <span className="text-xs">›</span>
          <span className="ml-1">Forgot your password?</span>
        </a>
      </div>
    </form>
  );
}